#ifndef __PCD8544_HW_H__
#define __PCD8544_HW_H__

#define PIN_RESET PD6
#define PIN_DC    PD7

#define LCD_C     0x00
#define LCD_D     0x01

#define LCD_X     84
#define LCD_Y     48

#define FONT_SIZE_1 0x01
#define FONT_SIZE_2 0x02
#define FONT_SIZE_3 0x03

#define PORT_PCD8544 PORTD
#define DDR_PCD8544  DDRD

extern void pcd8544_init(uint8_t cs);
extern void pcd8544_send(uint8_t dc, uint8_t data);
extern void pcd8544_print_string_fb(char *str);
extern void pcd8544_send_char_fb(uint8_t ch);
extern void pcd8544_clear(void);
extern void pcd8544_clear_fb(void);
extern void pcd8544_display_fb();
extern void pcd8544_set_cursor(uint8_t x, uint8_t y);
extern void pcd8544_set_cursor_fb(uint8_t x, uint8_t y);
extern void pcd8544_print_at_fb(char *str, uint8_t size, uint8_t x, uint8_t y);
extern void pcd8544_send_char_size2_fb(uint8_t ch, uint8_t x, uint8_t y);
extern void pcd8544_send_char_size3_fb(uint8_t ch, uint8_t x, uint8_t y);
extern void pcd8544_print_uint8_at_fb(uint8_t num, uint8_t size, uint8_t x, uint8_t y);
extern void pcd8544_set_point(uint8_t x, uint8_t y);
extern void pcd8544_draw_circle(uint8_t x0, uint8_t y0, uint8_t radius);
extern void pcd8544_draw_line(uint8_t x1, uint8_t y1, uint8_t x2, uint8_t y2);
extern void pcd8544_draw_icon_fb(char * img, uint8_t x,uint8_t y, uint8_t num);
#endif
